# Databricks notebook source
# MAGIC
# MAGIC %run "/Users/amarnadh.reddy@outlook.com/Formula1/includes/config_file"

# COMMAND ----------

display(raw_folder_path)

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("folder_date","enter file date here")
folder_date = dbutils.widgets.get("folder_date")

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls(raw_folder_path))

# COMMAND ----------

dframe = spark.read.format("csv").option("header","true").load(f"{raw_folder_path}/{folder_date}/circuits.csv")
display(dframe)

# COMMAND ----------

from pyspark.sql.functions import lit
dframe = dframe.withColumnRenamed("circuitId","circuit_id")
dframe = dframe.withColumnRenamed("circuitRef","circuit_ref")
dframe = dframe.withColumn("folder_date", lit(folder_date))
dframe = time_column_ingestion(dframe)

# COMMAND ----------

#dbutils.fs.rm(f"{processed_folder_path}/circuits/", True)
dframe.write.format("delta").mode("overwrite").save(f"{processed_folder_path}/circuits/")

# COMMAND ----------

#fetch data from circuits folder as delta tables and seef
from delta.tables import DeltaTable
delta_table = DeltaTable.forPath(spark, f"{processed_folder_path}/circuits/")
