# Databricks notebook source
# MAGIC %md
# MAGIC - Register service principal in Azure Active directory
# MAGIC   -   In azure portal search microsoft entra and register in app registration and use the client and tenant id from there.
# MAGIC - Create the secret 
# MAGIC   - In the created Mentra registration, in Manage, Click certificates and secret and create a client secret and use it here
# MAGIC - Assign spark.conf.set with clinet id,tenant id, secret
# MAGIC - RBAC  
# MAGIC

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list("Secret-scope-formula1")

# COMMAND ----------

#step2
client_id = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-id-service-principal")
tenant_id =dbutils.secrets.get("Secret-scope-formula1","secret-tenant-id-service-principal-formula1")
secret = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-secret-service-principal")

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
          "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
          "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="Secret-scope-formula1",key="secret-formula1-client-secret-service-principal"),
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}

# Optionally, you can add <directory-name> to the source URI of your mount point.
dbutils.fs.mount(
  source = "abfss://demo@saformula1dbricks.dfs.core.windows.net/",
  mount_point = "/mnt/saformula1dbricks/demo",
  extra_configs = configs)

# COMMAND ----------

#step 4 - assign role in IAM as storage data blob contributer
#add the created service principal (Mentra Service principal) and assign the role

# COMMAND ----------

dbutils.fs.ls("/mnt/saformula1dbricks/demo")

# COMMAND ----------

def mounting_sa(storage_account_name, container_name):
    #getting credetials from secret scope
    client_id = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-id-service-principal")
    tenant_id =dbutils.secrets.get("Secret-scope-formula1","secret-tenant-id-service-principal-formula1")
    secret = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-secret-service-principal")
    #setting up configs
    configs = {"fs.azure.account.auth.type": "OAuth",
        "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="Secret-scope-formula1",key="secret-formula1-client-secret-service-principal"),
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}
    #unmount if already exists
    mount_point = f"/mnt/{storage_account_name}/{container_name}"
    if any(mount.mountPoint == mount_point for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(mount_point)
    #mouting all the folders
    dbutils.fs.mount(
      source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
      mount_point = f"/mnt/{storage_account_name}/{container_name}",
      extra_configs = configs)



# COMMAND ----------

mounting_sa("saformula1dbricks","demo")
mounting_sa("saformula1dbricks","raw")

# COMMAND ----------

dbutils.fs.ls("/mnt/saformula1dbricks/demo")