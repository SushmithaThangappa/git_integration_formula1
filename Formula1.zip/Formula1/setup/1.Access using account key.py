# Databricks notebook source
# MAGIC %md
# MAGIC - Set Access key in spark.config fs.azure.account.key
# MAGIC - use dbfs.utils to list
# MAGIC - then read the csv in storage account using access key   

# COMMAND ----------

spark.conf.set(
    "fs.azure.account.key.saformula1dbricks.dfs.core.windows.net",
    "IB0cuS96T4gsuJ2lcnxmplttTgkMJtzr0zOnI24ZWQwYlBeoBI6rw8+KAKPTisp6nWQLTYnM5NP4+AStUT5N4g=="
)

# COMMAND ----------

dbutils.fs.ls("abfss://demo@saformula1dbricks.dfs.core.windows.net/")

# COMMAND ----------

dframe = spark.read.format("csv").option("header","true").load("abfss://demo@saformula1dbricks.dfs.core.windows.net/")
display(dframe)