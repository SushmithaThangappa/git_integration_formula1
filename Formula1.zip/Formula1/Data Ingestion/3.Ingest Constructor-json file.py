# Databricks notebook source
# MAGIC %md
# MAGIC - Read constructors.json file using spark read
# MAGIC - Define schema
# MAGIC - Drop URL column
# MAGIC - Rename all columns with _ seperated
# MAGIC - add ingestion timestamp column
# MAGIC - write as parquet files
# MAGIC

# COMMAND ----------

# MAGIC %run "/Users/amarnadh.reddy@outlook.com/Formula1/includes/config_file"
# MAGIC

# COMMAND ----------

dbutils.widgets.text("folder_date","enter file date here")
folder_date = dbutils.widgets.get("folder_date")

# COMMAND ----------

dframe = spark.read.format("json").load(f"{raw_folder_path}/{folder_date}/constructors.json")
dframe.printSchema()

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,IntegerType,StringType
#define schema for constructors
constructors_schema = StructType([StructField("constructorId", IntegerType(), True),
                                   StructField("constructorRef", StringType(), True),
                                   StructField("name", StringType(), True),
                                   StructField("nationality", StringType(), True),
                                   StructField("url", StringType(), True)])

# COMMAND ----------

#drop Url column
from pyspark.sql.functions import lit
dframe = spark.read.format("json").schema(constructors_schema).load(f"{raw_folder_path}/{folder_date}/constructors.json")
dframe = dframe.drop("url")
#rename columns to specific format
dframe = dframe.withColumnRenamed("constructorId", "constructor_Id")
dframe = dframe.withColumnRenamed("constructorRef", "constructor_Ref")
dframe = dframe.withColumn("folder_date", lit(folder_date))
#add new column with current timestamp
from pyspark.sql.functions import current_timestamp
dframe = dframe.withColumn("ingestion_timestamp",current_timestamp())
display(dframe)

# COMMAND ----------


dframe.write.format("delta").mode("overwrite").save(f"{processed_folder_path}/constructors/")