# Databricks notebook source
# MAGIC %md
# MAGIC - Register service principal in Azure Active directory
# MAGIC   -   In azure portal search microsoft entra and register in app registration and use the client and tenant id from there.
# MAGIC - Create the secret 
# MAGIC   - In the created Mentra registration, in Manage, Click certificates and secret and create a client secret and use it here
# MAGIC - Assign spark.conf.set with clinet id,tenant id, secret
# MAGIC - RBAC  
# MAGIC

# COMMAND ----------

#step2
client_id = "1fff68a7-af78-4692-94e2-4ce1e10e1300"
tenant_id ="84104478-caaf-4c13-8419-9cc452775829"
secret = "nS38Q~pV0u41i4iiyzxwmKcXnZUFRaU7FNM.pbry"

# COMMAND ----------

#step3
spark.conf.set("fs.azure.account.auth.type.saformula1dbricks.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.saformula1dbricks.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.saformula1dbricks.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.saformula1dbricks.dfs.core.windows.net", secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.saformula1dbricks.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

#step 4 - assign role in IAM as storage data blob contributer
#add the created service principal (Mentra Service principal) and assign the role

# COMMAND ----------

dbutils.fs.ls("abfss://demo@saformula1dbricks.dfs.core.windows.net/")