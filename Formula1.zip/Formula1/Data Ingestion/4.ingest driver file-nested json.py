# Databricks notebook source
# MAGIC %md
# MAGIC - Read drivers.json nested json file using spark read
# MAGIC - Define schema
# MAGIC - Drop URL column
# MAGIC - Rename all columns with _ seperated
# MAGIC - add ingestion timestamp column
# MAGIC - write as parquet files
# MAGIC

# COMMAND ----------

# MAGIC %run "/Users/amarnadh.reddy@outlook.com/Formula1/includes/config_file"

# COMMAND ----------

dbutils.widgets.text("folder_date","enter file date here")
folder_date = dbutils.widgets.get("folder_date")

# COMMAND ----------

dframe = spark.read.format("json").load(f"{raw_folder_path}/{folder_date}/drivers.json")
dframe.printSchema()
display(dframe)

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, ShortType, StringType, IntegerType, DateType
name_schema = StructType([StructField("forename", StringType(), True),
                           StructField("surname", StringType(), True)])
drivers_schema = StructType([StructField("code", StringType(), True),
                              StructField("dob", DateType(), True),
                              StructField("driverId", IntegerType(), True),
                              StructField("driverRef", StringType(), True),
                              StructField("name", name_schema, True),
                              StructField("nationality", StringType(), True),
                              StructField("number", IntegerType(), True),
                              StructField("url", StringType(), True)
                              ])

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, concat, lit, col

drame = dframe.withColumnRenamed("driverId", "driver_Id")
drame = drame.withColumnRenamed("driverRef", "driver_Ref")
drame = drame.withColumnRenamed("number", "driver_Number")
dframe = dframe.withColumn("folder_date", lit(folder_date))
dframe = dframe.withColumn("ingestion_Time", current_timestamp())
dframe = dframe.withColumn("name", concat(col("name.forename"), lit(" "), col("name.surname")))
dframe = dframe.drop()

display(dframe)

# COMMAND ----------

dframe.write.format("delta").mode("overwrite").save(f"{processed_folder_path}/drivers/")