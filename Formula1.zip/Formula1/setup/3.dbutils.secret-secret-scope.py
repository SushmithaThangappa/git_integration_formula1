# Databricks notebook source
# MAGIC %md
# MAGIC - Step 1. create Azure key vault and add all the account keys, client id etc
# MAGIC - Step 2:Afterthat, type #secrets/createScope in dbricks homepageURL and link the azure key vault by entering resource ID and dns name
# MAGIC - step3: explore dbutils.secret

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list("Secret-scope-formula1")

# COMMAND ----------

account_key = dbutils.secrets.get(scope="Secret-scope-formula1",key="secret-formula1-account-key")
spark.conf.set("fs.azure.account.key.saformula1dbricks.dfs.core.windows.net", account_key)
dbutils.fs.ls("abfss://demo@saformula1dbricks.dfs.core.windows.net/")