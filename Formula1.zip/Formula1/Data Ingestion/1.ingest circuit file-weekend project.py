# Databricks notebook source
def mounting_sa(storage_account_name, container_name):
    #getting credetials from secret scope
    client_id = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-id-service-principal")
    tenant_id =dbutils.secrets.get("Secret-scope-formula1","secret-tenant-id-service-principal-formula1")
    secret = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-secret-service-principal")
    #setting up configs
    configs = {"fs.azure.account.auth.type": "OAuth",
        "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="Secret-scope-formula1",key="secret-formula1-client-secret-service-principal"),
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}
    #unmount if already exists
    mount_point = f"/mnt/{storage_account_name}/{container_name}"
    if any(mount.mountPoint == mount_point for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(mount_point)
    #mouting all the folders
    dbutils.fs.mount(
      source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
      mount_point = f"/mnt/{storage_account_name}/{container_name}",
      extra_configs = configs)



# COMMAND ----------

mounting_sa("saformula1dbricks","raw")
mounting_sa("saformula1dbricks","processed")

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType, IntegerType, DoubleType
#defining circuits schema
circuitsSchema= StructType([
  StructField("circuitId",IntegerType(),True),
  StructField("circuitRef",StringType(),True),
  StructField("name",StringType(),True),
  StructField("location",StringType(),True),
  StructField("country",StringType(),True),
  StructField("lat",DoubleType(),True),
  StructField("lng",DoubleType(),True),
  StructField("alt",IntegerType(),True),
  StructField("url",StringType(),True)
])

# COMMAND ----------

dframe = spark.read.format("csv").schema(circuitsSchema).option("header","true").load("/mnt/saformula1dbricks/raw/circuits.csv")
display(dframe)

# COMMAND ----------

dframe.printSchema()

# COMMAND ----------

#add timestamp column
from pyspark.sql.functions import current_timestamp,year,month,dayofmonth
dframe = dframe.withColumn("timestamp", current_timestamp())
dframe = dframe.withColumn("year", year(dframe.timestamp))
dframe = dframe.withColumn("month", month(dframe.timestamp))
dframe = dframe.withColumn("day", dayofmonth(dframe.timestamp))

# COMMAND ----------

#full load
circuits_dframe = dframe.write.format("delta").mode("overwrite").save("/mnt/saformula1dbricks/processed/circuits")
display(circuits_dframe)

# COMMAND ----------

#incremental load
from delta.tables import DeltaTable
existing_circuits_dframe = DeltaTable.forPath(spark,"/mnt/saformula1dbricks/processed/circuits")
existing_circuits_dframe.alias("existing").merge(dframe.alias("new"),"existing.circuitId = new.circuitId").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()



# COMMAND ----------

raceframe = spark.read.format("csv").option("header","true").load("/mnt/saformula1dbricks/raw/races.csv")
display(raceframe)
#define schema for races.csv
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType
schema=StructType([StructField("raceId", IntegerType(), True),
                   StructField("year", IntegerType(), True),
                   StructField("round", IntegerType(), True),
                   StructField("circuitId", IntegerType(), True),
                   StructField("name", StringType(), True),
                   StructField("date", DateType(), True),
                   StructField("time", StringType(), True),
                   StructField("url", StringType(), True)])
raceframe = spark.read.format("csv").schema(schema).option("header","true").load("/mnt/saformula1dbricks/raw/races.csv")
display(raceframe)

from pyspark.sql.functions import current_timestamp
from pyspark.sql.functions import *
raceframe = raceframe.withColumn("ingestion_date", current_timestamp())
raceframe = raceframe.withColumn("race_timestamp",concat(col("date"),lit(" "),col("time")))
display(raceframe)

# COMMAND ----------

selected_race_frame = raceframe.select(
    "raceId",
    "year",
    "round",
    "circuitId",
    "name",
    "ingestion_date",
    "race_timestamp"
)
selected_race_frame.write.format("delta").mode("overwrite").partitionBy("year").save("/mnt/saformula1dbricks/processed/races")