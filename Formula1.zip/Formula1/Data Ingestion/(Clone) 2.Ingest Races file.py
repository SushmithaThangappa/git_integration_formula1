# Databricks notebook source
# MAGIC %md
# MAGIC - Reading races file using spark data frame
# MAGIC - Define Schema for races data frame
# MAGIC - Add new column ingestion_date with timestamp
# MAGIC - Add new column races_time by concat() function
# MAGIC - PartionBy race year and write in storage account processed/races
# MAGIC
# MAGIC

# COMMAND ----------

dframe = spark.read.format("csv").option("header","true").load("/mnt/saformula1dbricks/raw/races.csv")
display(dframe)
dframe.printSchema()

# COMMAND ----------

#define schema for races.csv
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType
schema=StructType([StructField("raceId", IntegerType(), True),
                   StructField("year", IntegerType(), True),
                   StructField("round", IntegerType(), True),
                   StructField("circuitId", IntegerType(), True),
                   StructField("name", StringType(), True),
                   StructField("date", DateType(), True),
                   StructField("time", StringType(), True),
                   StructField("url", StringType(), True)])

# COMMAND ----------

dframe = spark.read.format("csv").schema(schema).option("header","true").load("/mnt/saformula1dbricks/raw/races.csv")
display(dframe)
dframe.printSchema()


# COMMAND ----------

from pyspark.sql.functions import current_timestamp
from pyspark.sql.functions import *
dframe = dframe.withColumn("ingestion_date", current_timestamp())
dframe = dframe.withColumn("race_timestamp",concat(col("date"),lit(" "),col("time")))
display(dframe)

# COMMAND ----------

selected_dframe = dframe.select(
    "raceId",
    "year",
    "round",
    "circuitId",
    "name",
    "ingestion_date",
    "race_timestamp"
)

# COMMAND ----------

dbutils.fs.rm("/mnt/saformula1dbricks/processed/races/", True)
selected_dframe.write.mode("overwrite").partitionBy("year").parquet("/mnt/saformula1dbricks/processed/races/")