# Databricks notebook source
# MAGIC %md
# MAGIC - Reading races file using spark data frame
# MAGIC - Define Schema for races data frame
# MAGIC - Add new column ingestion_date with timestamp
# MAGIC - Add new column races_time by concat() function
# MAGIC - PartionBy race year and write in storage account processed/races
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %run "/Users/amarnadh.reddy@outlook.com/Formula1/includes/config_file"

# COMMAND ----------

dbutils.widgets.text("folder_date","enter file date here")
folder_date = dbutils.widgets.get("folder_date")

# COMMAND ----------

dframe = spark.read.format("csv").option("header","true").load(f"{raw_folder_path}/{folder_date}/races.csv")
display(dframe)
dframe.printSchema()

# COMMAND ----------

#define schema for races.csv
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType
schema=StructType([StructField("raceId", IntegerType(), True),
                   StructField("year", IntegerType(), True),
                   StructField("round", IntegerType(), True),
                   StructField("circuitId", IntegerType(), True),
                   StructField("name", StringType(), True),
                   StructField("date", DateType(), True),
                   StructField("time", StringType(), True),
                   StructField("url", StringType(), True)])

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
from pyspark.sql.functions import *
dframe = dframe.withColumn("ingestion_date", current_timestamp())
dframe = dframe.withColumn("race_timestamp",concat(col("date"),lit(" "),col("time")))
dframe = dframe.withColumn("folder_date", lit(folder_date))
display(dframe)

# COMMAND ----------

dbutils.fs.rm("/mnt/saformula1dbricks/processed/races/", True)
dframe.write.mode("overwrite").format("delta").save(f"{processed_folder_path}/races/")