# Databricks notebook source
# MAGIC %run "../includes/config_file"

# COMMAND ----------

race_results_df = spark.table("f1_reporting.race_results_delta_tbl")
#display(race_results_df)
race_results_df.columns
display(race_results_df)

# COMMAND ----------

from pyspark.sql.functions import col, countDistinct, sum

# Finding the top 10 drivers with the most points
filter_df = (race_results_df
    .filter(col("race_Year").isin('2019', '2020'))
    .groupBy("driver_Name", "race_Year")
    .agg(
        sum(col("points")).alias("total_points"),
        countDistinct(col("race_name")).alias("total_races")
    )
    .orderBy(col("total_points").desc())
)

display(filter_df)

# COMMAND ----------

# demo of rank window function
#step 1 : Specify window_spec using PartionBy and OrderBY
#Step 2 : Apply rank function to the window_spec
from pyspark.sql.functions import col, sum, countDistinct, rank, desc
from pyspark.sql.window import Window

demo_df = race_results_df.filter(col("race_Year").isin('2019', '2020'))
demo_df = demo_df.groupBy("driver_Name", "race_Year").agg(
    sum(col("points")).alias("total_points"),
    countDistinct(col("race_name")).alias("total_races")
)

window_spec = Window.partitionBy("race_Year").orderBy(col("total_points").desc())
demo_df = demo_df.withColumn("rank", rank().over(window_spec))

display(demo_df)

# COMMAND ----------

from pyspark.sql.functions import col, sum, count, when


# Calculate wins before groupBy
race_results_with_wins = race_results_df.withColumn(
    "wins", when(col('position') == 1, 1).otherwise(0)
)

driver_standings = race_results_with_wins.filter(
    col('race_Year').isin('2019', '2020')
).groupBy(
    col("driver_Name"), col("driver_Nationality"), col("race_Year")
).agg(
    sum(col("points")).alias("total_points"),
    sum(col("wins")).alias("wins")
).orderBy(col("total_points").desc(), col("wins").desc())

display(driver_standings)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS f1_reporting.driver_standings_tbl;

# COMMAND ----------

driver_standings.write.mode("overwrite").format("delta").saveAsTable("f1_reporting.driver_standings_tbl")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_reporting.driver_standings_tbl

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS f1_reporting.constructor_standings_tbl;

# COMMAND ----------

# constructor standings
from pyspark.sql.functions import sum, count, when, col,rank
from pyspark.sql.window import Window
constructor_standings = race_results_df.groupBy(
    col("constructor_Name").alias("team_name"), 
    col("race_Year")
).agg(
    sum(col("points")).alias("total_points"),
    count(when(col("position") == 1, True)).alias("wins")
).orderBy(
    col("total_points").desc(), 
    col("wins").desc()
)

# window_spec = Window.partitionBy("race_Year").orderBy(col("total_points").desc())
# constructor_standings = constructor_standings.withColumn("rank", rank().over(window_spec))
display(constructor_standings)

constructor_standings.write.mode("overwrite").format("delta").saveAsTable("f1_reporting.constructor_standings_tbl")