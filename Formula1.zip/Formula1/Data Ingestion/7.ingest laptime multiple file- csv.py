# Databricks notebook source
# MAGIC %md
# MAGIC - Read laptimes multiple csv file using spark read
# MAGIC - Define schema
# MAGIC - Rename all columns with _ seperated
# MAGIC - add ingestion timestamp column
# MAGIC - write as parquet files
# MAGIC

# COMMAND ----------

dframe = spark.read.format("csv").load("/mnt/saformula1dbricks/raw/lap_times/lap_times_split*.csv")
display(dframe)
dframe.printSchema()

# COMMAND ----------

#define schema for pit_stops
from pyspark.sql.types import StructField, StructType, ShortType, StringType, IntegerType, DateType,FloatType
lap_times_schema = StructType([StructField("raceId", IntegerType(), True),
                               StructField("driverId", IntegerType(), True),
                               StructField("lap", IntegerType(), True),
                               StructField("position", IntegerType(), True),
                               StructField("time", StringType(), True),
                               StructField("milliseconds", IntegerType(), True),
                               StructField("fastestLap", IntegerType(), True)
                               ])
                               

# COMMAND ----------

dframe = spark.read.format("csv").schema(lap_times_schema).load("/mnt/saformula1dbricks/raw/lap_times/lap_times_split*.csv")
display(dframe)
dframe.printSchema()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, concat, lit, col

#rename resultId column t
dframe = dframe.withColumnRenamed("raceId", "race_Id")
dframe = dframe.withColumnRenamed("driverId", "driver_Id")
dframe = dframe.withColumn("ingestion_time",current_timestamp())
display(dframe)

# COMMAND ----------

dframe.write.mode("overwrite").parquet("/mnt/saformula1dbricks/processed/lap_times/")