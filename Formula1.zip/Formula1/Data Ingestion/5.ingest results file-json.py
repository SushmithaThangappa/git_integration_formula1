# Databricks notebook source
# MAGIC %md
# MAGIC - Read drivers.json nested json file using spark read
# MAGIC - Define schema
# MAGIC - Drop URL column
# MAGIC - Rename all columns with _ seperated
# MAGIC - add ingestion timestamp column
# MAGIC - write as parquet files
# MAGIC

# COMMAND ----------

# MAGIC %run ../includes/config_file

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("folder_date", "enter date here")
folder_date = dbutils.widgets.get("folder_date")


# COMMAND ----------

dframe = spark.read.format("json").load(f"{raw_folder_path}/{folder_date}/results.json")
dframe.printSchema()
display(dframe)

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, ShortType, StringType, IntegerType, DateType,FloatType
results_schema = StructType([StructField("resultId", IntegerType(), True),
                             StructField("raceId", IntegerType(), True),
                             StructField("driverId", IntegerType(), True),
                             StructField("constructorId", IntegerType(), True),
                             StructField("number", IntegerType(), True),
                             StructField("grid", IntegerType(), True),
                             StructField("position", IntegerType(), True),
                             StructField("positionText", StringType(), True),
                             StructField("positionOrder", IntegerType(), True),
                             StructField("points", FloatType(), True),
                             StructField("laps", IntegerType(), True),
                             StructField("time", StringType(), True),
                             StructField("milliseconds", IntegerType(), True),
                             StructField("fastestLap", IntegerType(), True),
                             StructField("rank", IntegerType(), True),
                             StructField("fastestLapTime", StringType(), True),
                             StructField("fastestLapSpeed", FloatType(), True),
                             StructField("status", StringType(), True)])

                             

# COMMAND ----------

dframe = spark.read.format("json").schema(results_schema).load(f"{raw_folder_path}/{folder_date}/results.json")
dframe.printSchema()
display(dframe)


# COMMAND ----------

from pyspark.sql.functions import current_timestamp, concat, lit, col

#rename resultId column t
dframe = dframe.withColumnRenamed("resultId", "result_Id")
dframe = dframe.withColumnRenamed("raceId", "race_Id")
dframe = dframe.withColumnRenamed("driverId", "driver_Id")
dframe = dframe.withColumnRenamed("constructorId", "constructor_Id")
dframe = dframe.withColumn("folder_date", lit(folder_date))

dframe = dframe.withColumn("ingestion_Time", current_timestamp())
dframe = dframe.drop("status")

display(dframe)

# COMMAND ----------

dframe.write.mode("overwrite").format("delta").partitionBy("race_Id").save(f"{processed_folder_path}/results")

# COMMAND ----------

from delta.tables import DeltaTable
existing_results_dframe = DeltaTable.forPath(spark,f"{processed_folder_path}/results")
existing_results_dframe.alias("existing").merge(dframe.alias("new"),"existing.result_Id = new.result_Id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()