# Databricks notebook source


# COMMAND ----------

# MAGIC %run "../includes/config_file"

# COMMAND ----------

circuits_dframe = spark.read.format("csv").option("header", "true").load(f"{raw_folder_path}/circuits.csv")
circuits_dframe = circuits_dframe.withColumnRenamed("circuitId", "circuit_Id")
circuits_dframe = circuits_dframe.withColumnRenamed("circuitRef", "circuit_Ref")
circuits_dframe = circuits_dframe.withColumnRenamed("name", "circuit_Name")
circuits_dframe = circuits_dframe.withColumnRenamed("location", "circuit_Location")
circuits_dframe = circuits_dframe.withColumnRenamed("country", "circuit_Country")
circuits_dframe = circuits_dframe.withColumnRenamed("lat", "lattitude")
circuits_dframe = circuits_dframe.withColumnRenamed("lng", "longitude")
circuits_dframe = circuits_dframe.withColumnRenamed("alt", "Altitude")
circuits_dframe = circuits_dframe.withColumnRenamed("url", "circuit_URL")
display(circuits_dframe)
circuits_dframe.columns


# COMMAND ----------

races_dframe = spark.read.format("csv").option("header","true").load(f"{raw_folder_path}/races.csv")
from pyspark.sql.functions import current_timestamp
races_dframe = races_dframe.withColumnRenamed("raceId", "race_Id") \
                            .withColumnRenamed("raceName", "race_Name") \
                            .withColumnRenamed("circuitId", "circuit_Id") \
                            .withColumnRenamed("date", "race_Date") \
                            .withColumnRenamed("time", "race_Time") \
                            .withColumnRenamed("year", "race_Year") \
                            .withColumn("ingestion_time", current_timestamp())
races_dframe.columns

# COMMAND ----------

drivers_df = spark.read.format("json").load(f"{raw_folder_path}/drivers.json")
from pyspark.sql.types import StructField, StructType, ShortType, StringType, IntegerType, DateType
name_schema = StructType([StructField("forename", StringType(), True),
                           StructField("surname", StringType(), True)])
drivers_schema = StructType([StructField("code", StringType(), True),
                              StructField("dob", DateType(), True),
                              StructField("driverId", IntegerType(), True),
                              StructField("driverRef", StringType(), True),
                              StructField("name", name_schema, True),
                              StructField("nationality", StringType(), True),
                              StructField("number", IntegerType(), True),
                              StructField("url", StringType(), True)
                              ])
drivers_dframe = spark.read.format("json").schema(drivers_schema).load(f"{raw_folder_path}/drivers.json")
from pyspark.sql.functions import current_timestamp, concat, lit, col

drivers_df = drivers_df.withColumn("name", concat(col("name.forename"), lit(" "), col("name.surname")))
drivers_df = drivers_df.withColumnRenamed("driverId", "driver_Id")
drivers_df = drivers_df.withColumnRenamed("driverRef", "driver_Ref")
drivers_df = drivers_df.withColumnRenamed("number", "driver_Number")
drivers_df = drivers_df.withColumnRenamed("code", "driver_Code")
drivers_df = drivers_df.withColumnRenamed("name", "driver_Name")
drivers_df = drivers_df.withColumnRenamed("dob", "driver_DOB")
drivers_df = drivers_df.withColumnRenamed("nationality", "driver_Nationality")
drivers_df = drivers_df.withColumn("ingestion_time", current_timestamp())

drivers_df = drivers_df.drop()
display(drivers_df)

# COMMAND ----------

constructor_df = spark.read.format("json").load(f"{raw_folder_path}/constructors.json")
from pyspark.sql.functions import current_timestamp
constructor_df = constructor_df.withColumnRenamed("name", "constructor_Name") \
                                .withColumnRenamed("nationality", "constructor_Nationality")\
                                .withColumn("ingestion_time", current_timestamp())
display(constructor_df)

# COMMAND ----------

results_df = spark.read.format("json").load(f"{raw_folder_path}/results.json")
from pyspark.sql.functions import current_timestamp
results_df = results_df.withColumn("ingestion_time", current_timestamp())
display(results_df)
pitstops_dframe = spark.read.format("json").option("multiline",True).load(f"{raw_folder_path}/pit_stops.json")
from pyspark.sql.functions import current_timestamp
pitstops_dframe = pitstops_dframe.withColumn("ingestion_time", current_timestamp())

# COMMAND ----------

# Load multiple CSV files from laptime folder and create a table
laptime_dframe = spark.read.format("csv").option("header","true").load(f"{raw_folder_path}/lap_times/lap_times_split*.csv")
from pyspark.sql.functions import current_timestamp
laptime_dframe= laptime_dframe.withColumn("ingestion_time",current_timestamp())

# Load multiple multiline JSON files from qualifying folder
qualifying_dframe = spark.read.format("json").option("multiline", True).load(f"{raw_folder_path}/qualifying/*")
qualifying_dframe = qualifying_dframe.withColumn("ingestion_time",current_timestamp())

# COMMAND ----------

# MAGIC %sql
# MAGIC USE DATABASE f1_processed

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES

# COMMAND ----------

circuits_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_circuits_tbl")
races_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_races_tbl")
drivers_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_drivers_tbl")
constructor_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_constructors_tbl")
results_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_results_tbl")
laptime_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_laptimes_tbl")
qualifying_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_qualifying_tbl")
pitstops_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_processed.prcd_pitstops_tbl")




# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_processed.prcd_drivers_tbl

# COMMAND ----------

# Performing join and writing in reporting layer 
from pyspark.sql.functions import col

circuit_races_joined = circuits_dframe.alias("c").join(
    races_dframe.alias("r"),
    col("c.circuit_id") == col("r.circuit_id"),
    "inner"
)
circuit_races_joined.columns

#display(circuit_races_joined)

# COMMAND ----------

race_results_df = results_df.join(
    circuit_races_joined, 
    results_df["raceId"] == circuit_races_joined["race_Id"], 
    "inner"
).join(
    drivers_df, 
    results_df["driverId"] == drivers_df["driver_Id"], 
    "inner"
).join(
    constructor_df, 
    results_df["constructorId"] == constructor_df["constructorId"], 
    "inner"
)
display(race_results_df)

# COMMAND ----------

selected_race_results_df = race_results_df.select(col("race_Year"),col("name").alias("race_name"), col("race_Date"), col("circuit_Location"), col("driver_Name"),col("driver_Number"), col("driver_Nationality"),col("grid"),col("fastestLapTime"),col("position"),col("points"),col("constructor_Name"))
from pyspark.sql.functions import current_timestamp
selected_race_results_df = selected_race_results_df.withColumn("created_date", current_timestamp())
display(selected_race_results_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS f1_reporting

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS f1_reporting.race_results_delta_tbl;

# COMMAND ----------

selected_race_results_df.write.mode("overwrite").format("delta").saveAsTable("f1_reporting.race_results_delta_tbl")