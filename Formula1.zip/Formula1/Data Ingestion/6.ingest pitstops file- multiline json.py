# Databricks notebook source
# MAGIC %md
# MAGIC - Read drivers.json nested json file using spark read
# MAGIC - Define schema
# MAGIC - Drop URL column
# MAGIC - Rename all columns with _ seperated
# MAGIC - add ingestion timestamp column
# MAGIC - write as parquet files
# MAGIC

# COMMAND ----------

dframe = spark.read.format("json").option("multiline",True).load("/mnt/saformula1dbricks/raw/pit_stops.json")
display(dframe)

# COMMAND ----------

#define schema for pit_stops
from pyspark.sql.types import StructField, StructType, ShortType, StringType, IntegerType, DateType,FloatType
pit_stops_schema = StructType([StructField("driverId", IntegerType(), True),
                               StructField("raceId", IntegerType(), True),
                               StructField("lap", IntegerType(), True),
                               StructField("time", StringType(), True),
                               StructField("duration", FloatType(), True),
                               StructField("milliseconds", IntegerType(), True),
                               StructField("stop", IntegerType(), True),])
                               

# COMMAND ----------

dframe = spark.read.format("json").schema(pit_stops_schema).option("multiline",True).load("/mnt/saformula1dbricks/raw/pit_stops.json")
display(dframe)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, concat, lit, col

#rename resultId column t
dframe = dframe.withColumnRenamed("raceId", "race_Id")
dframe = dframe.withColumnRenamed("driverId", "driver_Id")
dframe= dframe.withColumn("ingestion_timestamp",current_timestamp())
display(dframe)

# COMMAND ----------

dframe.write.mode("overwrite").parquet("/mnt/saformula1dbricks/processed/pit_stops/")