# Databricks notebook source
# MAGIC %run ../includes/config_file

# COMMAND ----------

processed_folder_path

# COMMAND ----------

circuits_dframe = spark.read.format("delta").load(f"{processed_folder_path}/circuits/")
races_dframe = spark.read.format("delta").load(f"{processed_folder_path}/races/")
drivers_df = spark.read.format("delta").load(f"{processed_folder_path}/drivers/")
constructor_df= spark.read.format("delta").load(f"{processed_folder_path}/constructors/")
results_df= spark.read.format("delta").load(f"{processed_folder_path}/results/")



# COMMAND ----------

drivers_df = drivers_df.withColumnRenamed("name","driver_name")
drivers_df = drivers_df.withColumnRenamed("driverId","driver_Id")
drivers_df = drivers_df.withColumnRenamed("nationality","driver_nationality")
drivers_df = drivers_df.withColumnRenamed("number","driver_number")
constructor_df = constructor_df.withColumnRenamed("name","constructor_name")

# COMMAND ----------

from pyspark.sql.functions import col

circuit_races_joined = circuits_dframe.alias("c").join(
    races_dframe.alias("r"),
    col("c.circuit_id") == col("r.circuitId"),
    "inner"
)
circuit_races_joined.columns


# COMMAND ----------



race_results_df = results_df.join(
    circuit_races_joined, 
    results_df.race_Id == circuit_races_joined.raceId, 
    "inner"
).join(
    drivers_df, 
    results_df.driver_Id == drivers_df.driver_Id, 
    "inner"
).join(
    constructor_df, 
    results_df.constructor_Id == constructor_df.constructor_Id, 
    "inner"
)
display(race_results_df)

# COMMAND ----------



from pyspark.sql.functions import col, current_timestamp

selected_race_results_df = race_results_df.select(
    col("year").alias("race_year"),
    col("r.name").alias("race_name"),
    col("date").alias("race_date"),
    col("location").alias("circuit_location"),
    col("driver_name").alias("driver_name"),
    col("driver_number").alias("driver_number"),
    col("driver_nationality").alias("driver_nationality"),
    col("grid"),
    col("fastestLapTime"),
    col("position"),
    col("points"),
    col("constructor_name").alias("constructor_name")
)


selected_race_results_df = selected_race_results_df.withColumn("created_date", current_timestamp())
display(selected_race_results_df)

# COMMAND ----------

selected_race_results_df.write.mode("overwrite").format("parquet").save(f"{reporting_folder_path}/race_results")

# COMMAND ----------

race_results_df = spark.read.format("parquet").load(f"{reporting_folder_path}/race_results/")

# COMMAND ----------

from pyspark.sql.functions import col, sum, count, when


# Calculate wins before groupBy
race_results_with_wins = race_results_df.withColumn(
    "wins", when(col('position') == 1, 1).otherwise(0)
)

driver_standings = race_results_with_wins.filter(
    col('race_Year').isin('2019', '2020')
).groupBy(
    col("driver_Name"), col("driver_Nationality"), col("race_Year")
).agg(
    sum(col("points")).alias("total_points"),
    sum(col("wins")).alias("wins")
).orderBy(col("total_points").desc(), col("wins").desc())

display(driver_standings)

# COMMAND ----------

driver_standings.write.mode("overwrite").format("parquet").save(f"{reporting_folder_path}/driver_standings")

# COMMAND ----------

# constructor standings
from pyspark.sql.functions import sum, count, when, col,rank
from pyspark.sql.window import Window
constructor_standings = race_results_df.groupBy(
    col("constructor_Name").alias("team_name"), 
    col("race_Year")
).agg(
    sum(col("points")).alias("total_points"),
    count(when(col("position") == 1, True)).alias("wins")
).orderBy(
    col("total_points").desc(), 
    col("wins").desc()
)

# window_spec = Window.partitionBy("race_Year").orderBy(col("total_points").desc())
# constructor_standings = constructor_standings.withColumn("rank", rank().over(window_spec))
display(constructor_standings)

constructor_standings.write.mode("overwrite").format("parquet").save(f"{reporting_folder_path}/constructor_standings")