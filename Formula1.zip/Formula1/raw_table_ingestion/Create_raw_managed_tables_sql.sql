-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_raw;

-- COMMAND ----------

describe database f1_raw

-- COMMAND ----------

USE f1_raw;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(dbutils.fs.mounts())

-- COMMAND ----------

-- MAGIC %python 
-- MAGIC circuits_dframe = spark.read.format("csv").option("header", "true").load("/mnt/saformula1dbricks/raw/circuits.csv")
-- MAGIC races_dframe = spark.read.format("csv").option("header", "true").load("/mnt/saformula1dbricks/raw/races.csv")
-- MAGIC circuits_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.circuits_tbl")
-- MAGIC races_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.races_tbl")

-- COMMAND ----------

-- MAGIC %python 
-- MAGIC #single line json
-- MAGIC constructors_dframe = spark.read.format("json").load("/mnt/saformula1dbricks/raw/constructors.json")
-- MAGIC results_dframe = spark.read.format("json").load("/mnt/saformula1dbricks/raw/results.json")
-- MAGIC #multiline json
-- MAGIC pitstops_dframe = spark.read.format("json").option("multiline",True).load("/mnt/saformula1dbricks/raw/pit_stops.json")
-- MAGIC #nested json
-- MAGIC drivers_dframe = spark.read.format("json").load("/mnt/saformula1dbricks/raw/drivers.json")
-- MAGIC from pyspark.sql.types import StructField, StructType, ShortType, StringType, IntegerType, DateType
-- MAGIC name_schema = StructType([StructField("forename", StringType(), True),
-- MAGIC                            StructField("surname", StringType(), True)])
-- MAGIC drivers_schema = StructType([StructField("code", StringType(), True),
-- MAGIC                               StructField("dob", DateType(), True),
-- MAGIC                               StructField("driverId", IntegerType(), True),
-- MAGIC                               StructField("driverRef", StringType(), True),
-- MAGIC                               StructField("name", name_schema, True),
-- MAGIC                               StructField("nationality", StringType(), True),
-- MAGIC                               StructField("number", IntegerType(), True),
-- MAGIC                               StructField("url", StringType(), True)
-- MAGIC                               ])
-- MAGIC drivers_dframe = spark.read.format("json").schema(drivers_schema).load("/mnt/saformula1dbricks/raw/drivers.json")
-- MAGIC display(drivers_dframe)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC constructors_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.constructors_tbl")
-- MAGIC pitstops_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.pitstops_tbl")
-- MAGIC drivers_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.drivers_tbl")
-- MAGIC results_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.results_tbl")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #load multiple csv files from laptime folder and create a table
-- MAGIC laptime_dframe = spark.read.format("csv").load("/mnt/saformula1dbricks/raw/lap_times/lap_times_split*.csv")
-- MAGIC #load multiple multiline json from qualifying folder
-- MAGIC qualifying_dframe = spark.read.format("json").option("multiline",True).load("/mnt/saformula1dbricks/raw/qualifying/")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC laptime_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.laptime_tbl")
-- MAGIC qualifying_dframe.write.mode("overwrite").format("delta").saveAsTable("f1_raw.qualifying_tbl")

-- COMMAND ----------

DESC DATABASE f1_raw