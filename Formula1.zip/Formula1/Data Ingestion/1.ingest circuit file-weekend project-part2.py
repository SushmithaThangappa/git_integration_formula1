# Databricks notebook source
def mounting_sa(storage_account_name, container_name):
    #getting credetials from secret scope
    client_id = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-id-service-principal")
    tenant_id =dbutils.secrets.get("Secret-scope-formula1","secret-tenant-id-service-principal-formula1")
    secret = dbutils.secrets.get("Secret-scope-formula1","secret-formula1-client-secret-service-principal")
    #setting up configs
    configs = {"fs.azure.account.auth.type": "OAuth",
        "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "fs.azure.account.oauth2.client.id": client_id,
          "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="Secret-scope-formula1",key="secret-formula1-client-secret-service-principal"),
          "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"}
    #unmount if already exists
    mount_point = f"/mnt/{storage_account_name}/{container_name}"
    if any(mount.mountPoint == mount_point for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(mount_point)
    #mouting all the folders
    dbutils.fs.mount(
      source = f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
      mount_point = f"/mnt/{storage_account_name}/{container_name}",
      extra_configs = configs)



# COMMAND ----------

mounting_sa("saformula1dbricks","raw")
mounting_sa("saformula1dbricks","processed")
mounting_sa("saformula1dbricks","reporting")

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

reporting_race_dframe = spark.read.format("delta").load("/mnt/saformula1dbricks/processed/races/")
reporting_circuits_dframe = spark.read.format("delta").load("/mnt/saformula1dbricks/processed/circuits")

display(reporting_race_dframe)
display(reporting_circuits_dframe)

# COMMAND ----------

# Clean up the target path if it exists
dbutils.fs.rm("/mnt/saformula1dbricks/reporting", True)

# Write the DataFrame as a Delta table
circuits_by_country.write.format("delta").mode("overwrite").save("/mnt/saformula1dbricks/reporting")

# COMMAND ----------

# Inner join between races and circuits on circuitId
joined_df = reporting_race_dframe.join(reporting_circuits_dframe, 
                                       reporting_race_dframe.circuitId == reporting_circuits_dframe.circuitId, 
                                       "inner")

display(joined_df)


# COMMAND ----------

# Grouping by country and counting the number of races per country
country_race_count_df = joined_df.groupBy("country") \
                                 .count() \
                                 .orderBy("count", ascending=False)

# Display the total number of races per country
display(country_race_count_df)