# Databricks notebook source
raw_folder_path = '/mnt/saformula1dbricks/raw'
processed_folder_path = '/mnt/saformula1dbricks/processed'
reporting_folder_path = '/mnt/saformula1dbricks/reporting'


# COMMAND ----------

#common function
from pyspark.sql.functions import current_timestamp
def time_column_ingestion(input_df):
    output_df = input_df.withColumn('ingestion_time', current_timestamp())
    return output_df