# Databricks notebook source
# MAGIC %run ../includes/config_file

# COMMAND ----------

race_results_df = spark.read.parquet(f"{reporting_folder_path}/race_results")
race_results_df.columns

# COMMAND ----------

#creating temprorary view
race_results_df.createOrReplaceTempView("race_results_view")


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM race_results_view

# COMMAND ----------

#spark.sql returns a dataframe
# can be used when we need to pass dynamic paramters using fstring inside sql
view_results = spark.sql("select * from race_results_view where race_Year='2019'")
display(view_results)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS demoDb

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW DATABASES

# COMMAND ----------

# MAGIC %sql
# MAGIC USE DATABASE demodb

# COMMAND ----------

race_results_df.write.format("delta").mode("overwrite").saveAsTable("demodb.race_results_tbl")

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT * FROM demodb.race_results_tbl

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS demodb.race_results_sql_tbl
# MAGIC  AS
# MAGIC   SELECT * FROM demodb.race_results_tbl
# MAGIC   WHERE race_Year = 2019;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM race_results_sql_tbl