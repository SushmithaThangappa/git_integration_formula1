# Databricks notebook source
display(dbutils.fs.mounts())

# COMMAND ----------

display(dbutils.fs.ls("/mnt/saformula1dbricks/raw"))

# COMMAND ----------

dframe = spark.read.format("csv").option("header","true").load("/mnt/saformula1dbricks/raw/2021-03-21/circuits.csv")
display(dframe)

# COMMAND ----------

dframe = dframe.withColumnRenamed("circuitId","circuit_id")
dframe = dframe.withColumnRenamed("circuitRef","circuit_ref")
from pyspark.sql.functions import current_timestamp
dframe = dframe.withColumn("ingestion_time", current_timestamp())

# COMMAND ----------

# Write the DataFrame to a Delta table with a specified location
dframe.write.mode("overwrite").option("path", "abfss://processed@saformula1dbricks/circuits").saveAsTable("f1_processed.circuits")