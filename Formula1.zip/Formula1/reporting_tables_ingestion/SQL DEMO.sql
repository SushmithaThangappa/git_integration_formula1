-- Databricks notebook source
SHOW DATABASES

-- COMMAND ----------

USE f1_processed

-- COMMAND ----------

SHOW TABLES

-- COMMAND ----------

 SELECT * FROM prcd_drivers_tbl WHERE driver_Nationality = "French" LIMIT 10;
 

-- COMMAND ----------

--Concat Function
SELECT *, CONCAT(driver_Nationality, "-", driver_Code) AS new_Driver_Ref 
FROM prcd_drivers_tbl 

-- COMMAND ----------

--SPLIT FUNCTION
SELECT *, split(driver_Name," ")[0] AS first_name,split(driver_Name," ")[1] last_name FROM prcd_drivers_tbl LIMIT 10

-- COMMAND ----------

-- DATE FORMAT Function
SELECT date_format(ingestion_time, 'dd-MM-yyyy') AS extracted_date FROM prcd_drivers_tbl

-- COMMAND ----------

-- aggregate functions
SELECT count(1)  AS Total_drivers FROM prcd_drivers_tbl;

-- COMMAND ----------

-- Selecting youngest driver
SELECT driver_Name AS youngest_driver FROM prcd_drivers_tbl WHERE driver_DOB = (SELECT MAX(driver_DOB) FROM prcd_drivers_tbl);

-- COMMAND ----------

SELECT driver_Nationality, COUNT(driver_Nationality) AS total_drivers FROM prcd_drivers_tbl
  GROUP BY driver_Nationality
  ORDER BY total_drivers DESC;

-- COMMAND ----------

SELECT * FROM prcd_drivers_tbl WHERE driver_Code= "ROS"

-- COMMAND ----------

-- rank the youngest driver within a country 
SELECT driver_Name, driver_Nationality,driver_DOB, RANK() OVER(PARTITION BY driver_Nationality ORDER BY driver_DOB DESC) AS rank_within_country FROM prcd_drivers_tbl

-- COMMAND ----------

--join drivers,races and results table
CREATE TABLE f1_reporting.joined_drivers_races_results_tbl AS 
( SELECT driver_Name,raceId,race_Year,driverId,points,position FROM prcd_drivers_tbl INNER JOIN (
SELECT raceId,race_Year,driverId,points,position FROM prcd_races_tbl
 INNER JOIN  prcd_results_tbl 
 ON prcd_races_tbl.race_id = prcd_results_tbl.raceId) AS results
  ON results.driverId = prcd_drivers_tbl.driver_Id
)

-- COMMAND ----------

SELECT * FROM f1_reporting.joined_drivers_races_results_tbl WHERE driver_Name = "Lewis Hamilton"

-- COMMAND ----------

--Dominant drivers
SELECT DISTINCT driver_Name, race_Year,
  COUNT(1) AS Total_races,
  SUM(points) AS Total_Points,
  AVG(points) AS Avg_Points
FROM f1_reporting.joined_drivers_races_results_tbl
GROUP BY driver_Name, race_Year
HAVING Avg_Points >10
ORDER BY Total_Points DESC