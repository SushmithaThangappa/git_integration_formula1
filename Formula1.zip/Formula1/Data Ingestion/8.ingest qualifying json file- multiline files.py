# Databricks notebook source
# MAGIC %md
# MAGIC - Read qualifying.json nested json file using spark read
# MAGIC - Define schema
# MAGIC - Drop URL column
# MAGIC - Rename all columns with _ seperated
# MAGIC - add ingestion timestamp column
# MAGIC - write as parquet files
# MAGIC

# COMMAND ----------

dframe = spark.read.format("json").option("multiline",True).load("/mnt/saformula1dbricks/raw/qualifying/")
display(dframe)

# COMMAND ----------

#define schema for pit_stops
from pyspark.sql.types import StructField, StructType, ShortType, StringType, IntegerType, DateType,FloatType
qualifying_schema = StructType([StructField("qualifyId", IntegerType(), True),
                               StructField("constructorId", IntegerType(), True),
                               StructField("driverId", IntegerType(), True),
                               StructField("raceId", IntegerType(), True),
                               StructField("number", IntegerType(), True),
                               StructField("position", IntegerType(), True),
                               StructField("q1", StringType(), True),
                               StructField("q2", StringType(), True),
                               StructField("q3", StringType(), True),])
                               

# COMMAND ----------

dframe = spark.read.format("json").schema(qualifying_schema).option("multiline",True).load("/mnt/saformula1dbricks/raw/qualifying/")
display(dframe)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, concat, lit, col

#rename resultId column t
dframe = dframe.withColumnRenamed("raceId", "race_Id")
dframe = dframe.withColumnRenamed("driverId", "driver_Id")
dframe = dframe.withColumnRenamed("constructorId", "constructor_Id")
dframe = dframe.withColumnRenamed("qualifyId", "qualify_Id")
dframe= dframe.withColumn("ingestion_timestamp",current_timestamp())
display(dframe)

# COMMAND ----------

dframe.write.mode("overwrite").parquet("/mnt/saformula1dbricks/processed/qualifying/")