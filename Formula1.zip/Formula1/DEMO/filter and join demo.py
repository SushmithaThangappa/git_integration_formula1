# Databricks notebook source
# MAGIC %run "../includes/config_file"

# COMMAND ----------

circuits_dframe = spark.read.format("csv").load(f"{processed_folder_path}/circuits.csv")
circuits_dframe = circuits_dframe.withColumnRenamed("circuitId", "circuit_Id")
circuits_dframe = circuits_dframe.withColumnRenamed("circuitRef", "circuit_Ref")
circuits_dframe = circuits_dframe.withColumnRenamed("name", "circuit_Name")
circuits_dframe = circuits_dframe.withColumnRenamed("location", "circuit_Location")
circuits_dframe = circuits_dframe.withColumnRenamed("country", "circuit_Country")
circuits_dframe = circuits_dframe.withColumnRenamed("lat", "lattitude")
circuits_dframe = circuits_dframe.withColumnRenamed("lng", "longitude")
circuits_dframe = circuits_dframe.withColumnRenamed("alt", "Altitude")
circuits_dframe = circuits_dframe.withColumnRenamed("url", "circuit_URL")
#display(circuits_dframe)
circuits_dframe.columns


# COMMAND ----------

races_dframe = spark.read.format("parquet").load(f"{processed_folder_path}/race/")
races_dframe = races_dframe.withColumnRenamed("raceId", "race_Id") \
                            .withColumnRenamed("raceName", "race_Name") \
                            .withColumnRenamed("circuitId", "circuit_Id") \
                            .withColumnRenamed("date", "race_Date") \
                            .withColumnRenamed("time", "race_Time") \
                            .withColumnRenamed("year", "race_Year")
races_dframe.columns

# COMMAND ----------

drivers_df = spark.read.format("parquet").load(f"{processed_folder_path}/drivers/")
drivers_df = drivers_df.withColumnRenamed("driverId", "driver_Id")
drivers_df = drivers_df.withColumnRenamed("driverRef", "driver_Ref")
drivers_df = drivers_df.withColumnRenamed("number", "driver_Number")
drivers_df = drivers_df.withColumnRenamed("code", "driver_Code")
drivers_df = drivers_df.withColumnRenamed("name", "driver_Name")
drivers_df = drivers_df.withColumnRenamed("dob", "driver_DOB")
drivers_df = drivers_df.withColumnRenamed("nationality", "driver_Nationality")
#display(drivers_df)

# COMMAND ----------

constructor_df = spark.read.format("parquet").load(f"{processed_folder_path}/constructors/")
constructor_df = constructor_df.withColumnRenamed("name", "constructor_Name") \
                                .withColumnRenamed("nationality", "constructor_Nationality")
display(constructor_df)

# COMMAND ----------

results_df = spark.read.format("parquet").load(f"{processed_folder_path}/results/")
#display(results_df)

# COMMAND ----------

from pyspark.sql.functions import col

circuit_races_joined = circuits_dframe.alias("c").join(
    races_dframe.alias("r"),
    col("c.circuit_id") == col("r.circuit_id"),
    "inner"
)
circuit_races_joined.columns

#display(circuit_races_joined)

# COMMAND ----------

race_results_df = results_df.join(circuit_races_joined, results_df.race_Id == circuit_races_joined.race_Id, "inner") \
                            .join(drivers_df, results_df.driver_Id == drivers_df.driver_Id, "inner") \
                            .join(constructor_df, results_df.constructor_Id == constructor_df.constructor_Id, "inner")
race_results_df.columns


# COMMAND ----------

selected_race_results_df = race_results_df.select(col("race_Year"),col("name").alias("race_name"), col("race_Date"), col("circuit_Location"), col("driver_Name"),col("driver_Number"), col("driver_Nationality"),col("grid"),col("fastestLapTime"),col("position"),col("points"),col("constructor_Name"))
from pyspark.sql.functions import current_timestamp
selected_race_results_df = selected_race_results_df.withColumn("created_date", current_timestamp())
display(selected_race_results_df)

# COMMAND ----------

selected_race_results_df.write.mode("overwrite").parquet(f"{reporting_folder_path}/race_results")